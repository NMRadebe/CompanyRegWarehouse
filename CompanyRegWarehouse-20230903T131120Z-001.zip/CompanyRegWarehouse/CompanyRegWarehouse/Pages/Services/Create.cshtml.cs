using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace CompanyRegWarehouse.Pages.Services
{
    public class CreateModel : PageModel
    {
        public ServiceInfo serviceInfo = new ServiceInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }
        public void OnPost() 
        {
            serviceInfo.service = Request.Form["service"];
            serviceInfo.price = Request.Form["price"];

            if (serviceInfo.service.Length == 0 || serviceInfo.price.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

           try
            {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=companyRegWarehouse;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection (connectionString))
                {
                    connection.Open ();
                    String sql = "INSERT INTO services" +
                                    "(service, price) VALUES" +
                                    "@services,@price);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@service", serviceInfo.service);
                        command.Parameters.AddWithValue("@price", serviceInfo.price);

                        command.ExecuteNonQuery();
                    }


                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
           

            serviceInfo.service = ""; serviceInfo.price = "";
            successMessage = "New service added successfully";

            //Response.Redirect("/Services/Index");

        }
    }
}
