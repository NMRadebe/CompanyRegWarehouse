using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Net.Security;

namespace CompanyRegWarehouse.Pages.Services
{
    public class EditModel : PageModel
    {
        public ServiceInfo serviceInfo = new ServiceInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
            String id = Request.Query["id"];
            try
            {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=companyRegWarehouse;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM services WHERE id=@id";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                serviceInfo.id = "" + reader.GetInt32(0);
                                serviceInfo.service = reader.GetString(1);
                                serviceInfo.price = reader.GetString(2);






                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
        }

        public void OnPost()
        {
            serviceInfo.service = Request.Form["id"];
            serviceInfo.service = Request.Form["service"];
            serviceInfo.price = Request.Form["price"];

            if (serviceInfo.id.Length == 0 || serviceInfo.service.Length == 0 || serviceInfo.price.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=companyRegWarehouse;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE services" +
                                    "SET service=@service, price=@price" +
                                    "WHERE id=@id";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@service", serviceInfo.service);
                        command.Parameters.AddWithValue("@price", serviceInfo.price);
                        command.Parameters.AddWithValue("@id", serviceInfo.id);

                        command.ExecuteNonQuery();
                    }


                }
            }

            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Response.Redirect("/Services/Index");
        }
    }
}
