using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CompanyRegWarehouse.Pages.NewFolder4
{
    public class OrdersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
