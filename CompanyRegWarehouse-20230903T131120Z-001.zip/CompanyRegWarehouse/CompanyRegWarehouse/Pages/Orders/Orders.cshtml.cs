using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;


namespace CompanyRegWarehouse.Pages.Orders
{
    public class OrdersModel : PageModel
    {
        public List<ServiceInfo> listServices = new List<ServiceInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=companyRegWarehouse;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM services";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ServiceInfo serviceInfo = new ServiceInfo();
                                serviceInfo.id = reader.GetString(0);
                                serviceInfo.service = reader.GetString(1);
                                serviceInfo.price = reader.GetString(2);

                                listServices.Add(serviceInfo);




                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());

            }
        }
    }
    public class ServiceInfo
    {
        public String id;
        public String service;
        public String price;

    }
}
