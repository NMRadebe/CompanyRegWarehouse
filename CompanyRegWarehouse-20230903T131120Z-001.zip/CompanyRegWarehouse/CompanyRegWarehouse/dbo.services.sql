﻿CREATE TABLE [dbo].[services] (
    [id]      INT          IDENTITY (1, 1) NOT NULL,
    [service] VARCHAR (30) NOT NULL,
    [price]   FLOAT        NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC)
);

